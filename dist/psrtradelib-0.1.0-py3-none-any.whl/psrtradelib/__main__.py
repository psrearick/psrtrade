import helpers.Logger

def main():
    logger = helpers.Logger.Logger()
    logger.Log("Initializing psrtradelib")


if __name__ == '__main__':
    main()
